<?php
$databse="Worldcom";
$host = "localhost";
$username = "root";
$password = "";

// Create connection
$conn = mysqli_connect($host, $username, $password,$databse);

// Check connection
if ($conn) {
    echo "Connected successfully";
}

?>