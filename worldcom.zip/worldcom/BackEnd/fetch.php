<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</head>
<body>
    <?php
    include 'Connection.php';
    $sql="select * from user";
    $result=mysqli_query($conn,$sql);
    // if(mysqli_num_rows($result)>0){
    //     while($row=mysqli_fetch_array($result)){
    //         echo $row[2];
    //     }
    // }
    // else{
    //     echo"data not availble hare";
    // }
    
    ?>
<div class="container">
<h3 style="width:10%;margin:auto"><strong> All Data</strong> </h3>           
  <table class="table">
    <thead>
      <tr>
        <th>Id</th>
        <th>Name</th>
        <th>Email_Id</th>
        <th>Phone_number</th>
        <th>Action1</th>
        <th>Action2</th>
 
        
      </tr>
    </thead>
    <tbody>
 
<?php
    if(mysqli_num_rows($result)>0){
        while($row=mysqli_fetch_array($result)){?>
           
           <tr>
        <td><?php echo $row['id']?></td>
        <td><?php echo $row['Name']?></td>
        <td><?php echo $row['Email_id']?></td>
        <td><?php echo $row['Phone_number']?></td>
        <td>
        <form action="" method="post">
        <a type="Update" href="update.php?edit=<?php echo $row['id'];?>" class="btn btn-warning">Update</a></form>
        </td>

        <td>
  
        <form action="" method="post">
        <?php

if(isset($_GET['Delete'])){
    $id=$_GET('Delete');
    echo $id;
    $delete="DELETE FROM `user` WHERE id=$id";
    mysqli_query($conn,$delete);
    echo "data successfully deleted";
}
        ?>
<a href="delete.php?del=<?php echo $row['id']; ?>"  class="btn btn-danger" >Delete</a></form>
        </td>
  

      </tr>

     <?php   }
    }
    else{
        echo"data not availble hare";
    }
    
    ?>
   
     
    </tbody>
  </table>
</div>

</body>
</html>
