<?php
include 'Connection.php';
if(isset($_GET['del'])){
    $id= $_GET['del'];
    echo $id;
    $delete="DELETE FROM `user` WHERE id=$id";
    mysqli_query($conn,$delete);
    echo "data successfully deleted";
}
        ?>


        <br>
        <br>
        <a type="Update" href="fetch.php" class="btn btn-warning">See ALl data</a></form>