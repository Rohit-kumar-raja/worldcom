
    <!doctype html>
	<html lang="en">
	
	<head>
		<!-- Required meta tags -->
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	
		<!-- Bootstrap CSS --><link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css" integrity="sha384-50oBUHEmvpQ+1lW4y57PTFmhCaXp0ML5d60M1M7uH2+nqUivzIebhndOJK28anvf" crossorigin="anonymous">		<link rel="stylesheet" href="//use.fontawesome.com/releases/v5.0.7/css/all.css">
		<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css"
			integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
		<link rel="preconnect" href="https://fonts.gstatic.com">
		<link href="https://fonts.googleapis.com/css2?family=Timmana&display=swap" rel="stylesheet">
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	
		<link rel="stylesheet" href="index.css">
		<link rel="stylesheet" href="footer.css">
	
		<link rel="stylesheet" href="productcart.css">
		<link rel="icon" href="./imagesouce/logo.png">
		<link rel="stylesheet" href="contact.css">
		<link rel="stylesheet" href="search.css">
		<link rel="stylesheet" href="payment.css">
		<title>Hello, world!</title>
	</head>
	
	<body>
	<?php
include './headerdetails/searchcontact.html';
?>
		<div class="container py-5">
			<!-- For demo purpose -->
			<div class="row mb-4">
				<div class="col-lg-8 mx-auto text-center">
					<h1 class="display-6">Payment methods</h1>
				</div>
			</div> <!-- End -->
	
			<article class="card">
				<div class="card-body p-5">
	
					<ul class="nav bg-light nav-pills rounded nav-fill mb-3" role="tablist">
						<li class="nav-item">
							<a class="nav-link active" data-toggle="pill" href="#nav-tab-card">
								<i class="fa fa-credit-card"></i> Credit/Debit Card</a>
						</li>
						<li class="nav-item">
							<a class="nav-link" data-toggle="pill" href="#nav-tab-paypal">
								<i class="fas fa-wallet"></i>Wallet</a>
						</li>
						<li class="nav-item">
							<a class="nav-link" data-toggle="pill" href="#nav-tab-bank">
								<i class="fa fa-university"></i>Upi</a>
						</li>
					</ul>
	
					<div class="tab-content">
						<div class="tab-pane fade show active" id="nav-tab-card">
							<p class="alert alert-success">Some text success or error</p>
							<form role="form">
								<div class="form-group">
									<label for="username">Full name (on the card)</label>
									<input type="text" class="form-control" name="username" placeholder="" required="">
								</div> <!-- form-group.// -->
	
								<div class="form-group">
									<label for="cardNumber">Card number</label>
									<div class="input-group">
										<input type="text" class="form-control" name="cardNumber" placeholder="">
										<div class="input-group-append">
											<span class="input-group-text text-muted">
												<i class="fab fa-cc-visa"></i>   <i class="fab fa-cc-amex"></i>  
												<i class="fab fa-cc-mastercard"></i>
											</span>
										</div>
									</div>
								</div> <!-- form-group.// -->
	
								<div class="row">
									<div class="col-sm-8">
										<div class="form-group">
											<label><span class="hidden-xs">Expiration</span> </label>
											<div class="input-group">
												<input type="number" class="form-control" placeholder="MM" name="">
												<input type="number" class="form-control" placeholder="YY" name="">
											</div>
										</div>
									</div>
									<div class="col-sm-4">
										<div class="form-group">
											<label data-toggle="tooltip" title=""
												data-original-title="3 digits code on back side of the card">CVV <i
													class="fa fa-question-circle"></i></label>
											<input type="number" class="form-control" required="">
										</div> <!-- form-group.// -->
									</div>
								</div> <!-- row.// -->
								<button class="subscribe btn btn-primary btn-block" type="button"> Confirm </button>
							</form>
						</div> <!-- tab-pane.// -->
						<div class="tab-pane fade" id="nav-tab-paypal">
							<p>Wallet is easiest way to pay online</p>
							<select class="form-control" name="upi" id="upi">
						<option selected disabled value="Phonepe">Choose...</option>
						<option value="Phonepe">Phone pe</option>
						<option value="Phonepe">Phone pe</option>
						<option value="Phonepe">Phone pe</option>
						<option value="Phonepe">Phone pe</option>
						<option value="Phonepe">Phone pe</option>
						<option value="Phonepe">Phone pe</option>
						<option value="Phonepe">Phone pe</option>
						<option value="Phonepe">Phone pe</option>
					</select>
							<p>
								<button type="button" class="btn btn-primary"> <i class="fas fa-wallet"></i> Log in my
									Paypal </button>
							</p>
							<p><strong>Note:</strong> Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do
								eiusmod
								tempor incididunt ut labore et dolore magna aliqua. </p>
						</div>
						<div class="tab-pane fade" id="nav-tab-bank">
						<form role="form">
								<div class="form-group">
								<select class="form-control" name="upi" id="upi">
						<option selected disabled value="Phonepe">Choose...</option>
						<option value="Phonepe">Phone pe</option>
						<option value="Phonepe">Phone pe</option>
						<option value="Phonepe">Phone pe</option>
						<option value="Phonepe">Phone pe</option>
						<option value="Phonepe">Phone pe</option>
						<option value="Phonepe">Phone pe</option>
						<option value="Phonepe">Phone pe</option>
						<option value="Phonepe">Phone pe</option>
					</select>
									
								</div> <!-- row.// -->
								<button class="subscribe btn btn-primary btn-block" type="button"> Confirm </button>
							</form>

						</div> <!-- tab-pane.// -->
					</div> <!-- tab-content .// -->
	
				</div> <!-- card-body.// -->
			</article> <!-- card.// -->
		</div>
	
		<!-- jQuery first, then Popper.js, then Bootstrap JS -->
		<script src="payment.js"></script>
		<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"
			integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo"
			crossorigin="anonymous"></script>
		<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"
			integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1"
			crossorigin="anonymous"></script>
		<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"
			integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM"
			crossorigin="anonymous"></script>
	</body>
	<?php
		  include 'simplefooter.html';
		  ?>
	
	</html>