<!doctype html>
<html lang="en">

<head>
	<!-- Required meta tags -->
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

	<!-- Bootstrap CSS -->
	<link rel="stylesheet" href="//use.fontawesome.com/releases/v5.0.7/css/all.css">
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css"
    integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
  <link rel="preconnect" href="https://fonts.gstatic.com">
  <link href="https://fonts.googleapis.com/css2?family=Timmana&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

  <link rel="stylesheet" href="index.css">
  <link rel="stylesheet" href="footer.css">
<link rel="stylesheet" href="Login.css">
  <link rel="stylesheet" href="productcart.css">

  <link rel="stylesheet" href="contact.css">
  <link rel="stylesheet" href="search.css">
  <link rel="stylesheet" href="cart.css">

	<title>World com Add to cart</title>

</head>

<body>

	<?php
	include './headerdetails/searchcontact.html';
	?>
		<!-- End -->

		<div class="pb-5">
			<div class="container">
				<div class="row-own">
					<div class="col-lg-12 p-5 bg-white rounded shadow-sm mb-5">

						<!-- Shopping cart table -->
						<div class="table-responsive">
							<table class="table">
								<thead>
									<tr>
										<th scope="col" class="border-0 bg-light">
											<div class="p-2 px-3 text-uppercase">Product</div>
										</th>
										<th scope="col" class="border-0 bg-light">
											<div class="py-2 text-uppercase">Price</div>
										</th>
										<th scope="col" class="border-0 bg-light">
											<div class="py-2 text-uppercase">Quantity</div>
										</th>
										<th scope="col" class="border-0 bg-light">
											<div class="py-2 text-uppercase">Remove</div>
										</th>
									</tr>
								</thead>
								<tbody>
									<tr>
										<th scope="row" class="border-0">
											<div class="p-2">
												<img src="https://res.cloudinary.com/mhmd/image/upload/v1556670479/product-1_zrifhn.jpg"
													alt="" width="70" class="img-fluid rounded shadow-sm">
												<div class="ml-3 d-inline-block align-middle">
													<h5 class="mb-0"> <a href="#"
															class="text-dark d-inline-block align-middle">Timex Unisex
															Originals</a></h5><span
														class="text-muted font-weight-normal font-italic d-block">Category:
														Watches</span>
												</div>
											</div>
										</th>
										<td class="border-0 align-middle"><strong>$79.00</strong></td>
										<td class="border-0 align-middle"><strong>3</strong></td>
										<td class="border-0 align-middle"><a href="#" class="text-dark"><i
													class="fa fa-trash"></i></a></td>
									</tr>
									<tr>
										<th scope="row">
											<div class="p-2">
												<img src="https://res.cloudinary.com/mhmd/image/upload/v1556670479/product-3_cexmhn.jpg"
													alt="" width="70" class="img-fluid rounded shadow-sm">
												<div class="ml-3 d-inline-block align-middle">
													<h5 class="mb-0"><a href="#" class="text-dark d-inline-block">Lumix
															camera lense</a></h5><span
														class="text-muted font-weight-normal font-italic">Category:
														Electronics</span>
												</div>
											</div>
										</th>
										<td class="align-middle"><strong>$79.00</strong></td>
										<td class="align-middle"><strong>3</strong></td>
										<td class="align-middle"><a href="#" class="text-dark"><i
													class="fa fa-trash"></i></a>
										</td>
									</tr>
									<tr>
										<th scope="row">
											<div class="p-2">
												<img src="https://res.cloudinary.com/mhmd/image/upload/v1556670479/product-2_qxjis2.jpg"
													alt="" width="70" class="img-fluid rounded shadow-sm">
												<div class="ml-3 d-inline-block align-middle">
													<h5 class="mb-0"> <a href="#" class="text-dark d-inline-block">Gray
															Nike running shoe</a></h5><span
														class="text-muted font-weight-normal font-italic">Category:
														Fashion</span>
												</div>
											</div>
										<td class="align-middle"><strong>$79.00</strong></td>
										<td class="align-middle"><strong>3</strong></td>
										<td class="align-middle"><a href="#" class="text-dark"><i
													class="fa fa-trash"></i></a>
										</td>
									</tr>
								</tbody>
							</table>
						</div>
						<!-- End -->
					</div>
				</div>

				<div class="row py-5 p-4 bg-white rounded shadow-sm">
					
					<div class="col-lg-6">
						<div class="bg-light rounded-pill px-4 py-3 text-uppercase font-weight-bold">Order summary
						</div>
						<div class="p-4">
							<p class="font-italic mb-4">Shipping and additional costs are calculated based on values you
								have entered.</p>
							<ul class="list-unstyled mb-4">
								<li class="d-flex justify-content-between py-3 border-bottom"><strong
										class="text-muted">Order Subtotal </strong><strong>$390.00</strong></li>
								<li class="d-flex justify-content-between py-3 border-bottom"><strong
										class="text-muted">Shipping and handling</strong><strong>$10.00</strong></li>
								<li class="d-flex justify-content-between py-3 border-bottom"><strong
										class="text-muted">Tax</strong><strong>$0.00</strong></li>
								<li class="d-flex justify-content-between py-3 border-bottom"><strong
										class="text-muted">Total</strong>
									<h5 class="font-weight-bold">$400.00</h5>
								</li>
								<div class="input-group mb-4 border rounded-pill p-2">
								<input type="text" placeholder="Apply coupon" aria-describedby="button-addon3"
									class="form-control border-0">
							
								</div>
								<div class="input-group-append border-0">
									<button id="button-addon3" type="button" class="btn btn-dark px-4 rounded-pill"><i
											class="fa fa-gift mr-2"></i>Apply coupon</button>
							</div>
							</ul><a href="billing.php" class="btn btn-dark rounded-pill py-2 btn-block">Procceed to checkout</a>
						</div>
					</div>
				</div>

			</div>
		</div>
	</div>
	<?php
	include 'simplefooter.html';
	?>
	<!--Section: Block Content-->

	<!-- Optional JavaScript -->
	<!-- jQuery first, then Popper.js, then Bootstrap JS -->
	<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"
		integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo"
		crossorigin="anonymous"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"
		integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1"
		crossorigin="anonymous"></script>
	<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"
		integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM"
		crossorigin="anonymous"></script>
</body>

</html>