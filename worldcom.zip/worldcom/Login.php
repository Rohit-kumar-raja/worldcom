<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

  <!-- Bootstrap CSS -->
 
  <link rel="stylesheet" href="//use.fontawesome.com/releases/v5.0.7/css/all.css">
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css"
    integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
  <link rel="preconnect" href="https://fonts.gstatic.com">
  <link href="https://fonts.googleapis.com/css2?family=Timmana&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

  <link rel="stylesheet" href="index.css">
  <link rel="stylesheet" href="footer.css">
<link rel="stylesheet" href="Login.css">
  <link rel="stylesheet" href="productcart.css">

  <link rel="stylesheet" href="contact.css">
  <link rel="stylesheet" href="search.css">


    <!-- Roboto Font -->

    <!-- Your custom styles (optional) -->

</head>

<body class="skin-light" aria-busy="true">
<?php
include './headerdetails/searchcontact.html';
?>

    <!--Main Navigation-->

    <!--Main layout-->
    <main>

        <div class="container">
            <!--Grid row-->
            <div class="row row1 d-flex justify-content-center">

                <!--Grid column-->
                <div class="col-md-6">

                    <!--Section: Content-->
                    <section class="mb-5">

                        <form action="#!">

                            <div class="md-form md-outline">
                            <label data-error="wrong" data-success="right" for="defaultForm-email1"> <i class=" password fa fa-envelope"></i> Your
                                    email</label>
                                <input  type="email" id="defaultForm-email1" class="form-control">
                               
                            </div>
                            <label data-error="wrong" data-success="right" for="defaultForm-pass1">
                            <i class=" password fa fa-key" aria-hidden="true"></i>  password</label>
                            <div class="md-form md-outline">
                                <input type="password" id="defaultForm-pass1" class="form-control">
                              
                            </div>
                   
                        </form>

                        <div class="d-flex justify-content-between align-items-center mb-2">

                            <div class="form-check pl-0 mb-3">
                                <input type="checkbox" class="form-check-input filled-in" id="new">
                                <label class="form-check-label small text-uppercase card-link-secondary"
                                    for="new">Remember me</label>
                            </div>

                            <p><a href="">Forgot password?</a></p>

                        </div>
           

                        <div class="text-center pb-2">

                            <button type="submit" class="btn btn-primary mb-4 waves-effect waves-light">Sign in</button>

                            <p>Not a member? <a  href="Singnup.php">Register</a></p>

                            <p>or sign in with:</p>
                            <a type="button" class="btn-floating btn-fb btn-sm mr-1 waves-effect waves-light">
                                <i class="fab fa-google"></i>
                            </a>
                            <a type="button" class="btn-floating btn-fb btn-sm mr-1 waves-effect waves-light">
                                <i class="fab fa-facebook-f"></i>
                            </a>
                            <a type="button" class="btn-floating btn-tw btn-sm mr-1 waves-effect waves-light">
                                <i class="fab fa-twitter"></i>
                            </a>
                            <a type="button" class="btn-floating btn-li btn-sm mr-1 waves-effect waves-light">
                                <i class="fab fa-linkedin-in"></i>
                            </a>
                            <a type="button" class="btn-floating btn-git btn-sm waves-effect waves-light">
                                <i class="fab fa-github"></i>
                            </a>

                        </div>

                    </section>
                    <!--Section: Content-->

                </div>
                <!--Grid column-->

            </div>
            <!--Grid row-->


        </div>
    </main>
    <!--Main layout-->
<?php
include 'simplefooter.html';
?>

    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"
        integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo"
        crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"
        integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1"
        crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"
        integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM"
        crossorigin="anonymous"></script>
</body>

</html>